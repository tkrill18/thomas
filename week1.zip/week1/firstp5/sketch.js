function setup() {
    ellipse(50,50,80,80);
}