function setup() {
    createCanvas(500, 300);
}

var x = 0;
function draw() {
    background(100);
    ellipse(x, 150, 100)
    x++;
}