// MAIN
var kabutopsHP = 60;
var kabutopsNum = 141;
var kabutopsType = "Rock and Water";
var kabutopsBestMove = "Hydro Pump";
var kabutopsLastEvo = true;

// BONUS
// 1)
var kabutopsAttack = 115;
var kabutopsDefense = 105;
var kabutopsSpAtk = 65;
var kabutopsSpDef = 70;
var kabutopsSpeed = 80;

// 2)
var ninetalesHP = 73;
var ninetalesNum = 38;
var ninetalesType = "Fire";
var ninetalesBestMove = "Fire Blast";
var ninetalesLastEvo = true;

var ninetalesAttack = 76;
var ninetalesDefense = 75;
var ninetalesSpAtk = 81;
var ninetalesSpDef = 100;
var ninetalesSpeed = 100;


var dragonairHP = 61;
var dragonairNum = 148;
var dragonairType = "Dragon";
var dragonairBestMove = "Dragon Rage";
var dragonairLastEvo = false;

var dragonairAttack = 84;
var dragonairDefense = 65;
var dragonairSpAtk = 70;
var dragonairSpDef = 70;
var dragonairSpeed = 70;

// 3)
kabutopsHP = kabutopsHP - 50;
ninetalesHP = ninetalesHP - 50;
dragonairHP = dragonairHP - 50;