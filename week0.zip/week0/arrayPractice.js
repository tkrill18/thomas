
// This will print "Mahdi rules" out 5 times.
// console.log("Mahdi rules");
// console.log("Mahdi rules");
// console.log("Mahdi rules");
// console.log("Mahdi rules");
// console.log("Mahdi rules");

for (var i = 0; i < 10; i++) {
    console.log(i);
}



// 0
// 1
// 2
// 3
// 4
