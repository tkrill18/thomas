var level = 1;

if (level % 2 == 0) {
    console.log("You're on an even level!");
}
else {
    console.log("You're on an odd level!");
}